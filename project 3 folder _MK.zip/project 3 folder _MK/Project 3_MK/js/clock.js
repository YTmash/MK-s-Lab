// setup a 24 hour clock and display to page
function startClock() {
    let nowTime = new Date();
    let hours = nowTime.getHours();
    let minutes = nowTime.getMinutes();
    // console.log(hours);
    // console.log(minutes);
    // console.log (seconds);

    // check for leading 0s on minutes and seconds
    minutes = checkTime(minutes);
    seconds = checkTime(seconds);

    document.getElementById('clock.innerHTML') = hours + ":" + minutes + ":" + seconds;



// check for a leading 0 and add one if necessary
function checkTime(data) {
    if (data < 10) {
        data = '0' + data;
    }  
    return data;
}

//startClock(); // call function
setinterval (startClock, 1000)

    function setinterval() {
    const date = new Date();
    document.getElementById("date").innerHTML = date;
      const today = new Date();
      let h = today.getHours();
      let m = today.getMinutes();
      let s = today.getSeconds();
      m = checkTime(m);
      s = checkTime(s);
      document.getElementById('curtime').innerHTML =  h + ":" + m + ":" + s;
      setinterval(startTime, 1000);
    }
    
    function checkTime(i) {
      if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
      return i;
    }
  }
  
  function currentTime() {
let date = new Date(); 
let hh = date.getHours();
let mm = date.getMinutes();
let ss = date.getSeconds();
let session = "AM";

if(hh == 0){
  hh = 12;
}
if(hh > 12){
  hh = hh - 12;
  session = "PM";
}

hh = (hh < 10) ? "0" + hh : hh;
mm = (mm < 10) ? "0" + mm : mm;
ss = (ss < 10) ? "0" + ss : ss;

let time = hh + ":" + mm + ":" + ss + " " + session;

document.getElementById("clock").innerText = time; 
let t = setTimeout(function(){ currentTime() }, 1000);
}
currentTime();
