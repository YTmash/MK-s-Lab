// array of banner image file paths
const adImages = [
    'img/adbanners/ads/CIBC_Bank_USA_Logo.png',
    'img/adbanners/ads/miramax logo.jpg',
    'img/adbanners/ads/mlb-logo.png',
    'img/adbanners/ads/royal bank logo.jpg',
    'img/adbanners/ads/siemens logo.png',
  ];

// counter variable for what ad is being displayed
let thisAd = 0;

// create a random number every time the page loads which will be 0 to length of the adImages array - 1
function randomAd() {
thisAd = Math.floor(Math.random() * adImages.length);
document.getElementById('adBanner').src = adImages[thisAd];
addLinks();
}

// make sure we have a link tag and set an onclick event to call a function to add the correct link
function addLinks() {
if (document.getElementById('adBanner').parentNode.tagName == "A") {
document.getElementById('adBanner').parentNode.onclick = newLocation;
}
rotate();
}

// array of ad links to display when image ad is clicked
function newLocation() {
const adURL = [
"cibc.com/en/cibc-websites.html",
"miramax.com",
"mlb.com/HomePage",
"rbc.com/canada.html",
"siemens.com/global/en.html",
];

window.open("https://www." + adURL[thisAd]);
// stop the anchor tag from performing its default behaviour
return false;
}

// check if at the end of the array and reset to start, rotate images after 5 seconds
function rotate() {
thisAd++;
if (thisAd == adImages.length) {
thisAd = 0;
}
document.getElementById('adBanner').src = adImages[thisAd];
setTimeout(rotate, 5000); // rotates the banner in ms
}

// start the ad banner after page loads
randomAd();